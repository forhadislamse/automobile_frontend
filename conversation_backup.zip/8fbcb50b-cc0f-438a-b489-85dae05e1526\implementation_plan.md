# Migrate Regwheat Frontend to Automobile Frontend

You want to bring the entire `regwheat_frontend` project into your current `automobile_frontend` project while maintaining the new "Light Orange" premium theme and the "NextGen AutoTech" branding. 

## User Review Required

> [!WARNING]
> This will copy hundreds of files from `regwheat_frontend` (including the full Dashboard, Chat layout, Onboarding, Authentication pages, APIs, and Contexts) into this project. It will overwrite matching files but **will preserve your new SVG Logo, Favicon, and the Light Orange theme.**

## Open Questions

None at the moment. 

## Proposed Changes

### 1. Copy All Missing Files
I will run a sync command to copy all folders from `regwheat_frontend` that are missing in `automobile_frontend`:
- `src/app/*` (e.g., `chatLayout`, `shop-owner`, `admin-login`, `payment`, `user-guide` etc.)
- `components/*` (all remaining UI and shared components)
- `redux/*` (any remaining reducers, APIs)
- `context/`, `libs/`, `hooks/`

### 2. Apply "Light Orange" Theme Globally
The `regwheat_frontend` uses Dark Blue and Red (`#0A2149`, `#7E0A0A`, `#8B2323`, `#1B4697`, etc.). 
I will run a global color replacement across the newly copied files to convert them to your requested **Light Orange (`#FF6B00`)** and **Dark Slate (`#0F172A`)** premium theme, so the entire website (Dashboards, Login, Register, etc.) matches the beautiful Landing Page.

### 3. Sync Dependencies
I will merge any missing dependencies from `regwheat_frontend`'s `package.json` into this project and run `npm install`.

### 4. Branding Preservation
I will ensure that your new `favicon.svg` and the "NextGen AutoTech" name in the site metadata remain intact.

## Verification Plan

### Automated Tests
- `npm run build` to verify there are no missing modules, type errors, or broken imports in any of the newly copied pages.

### Manual Verification
- You can browse the `/login`, `/register`, and dashboard routes locally to verify the new color theme is applied everywhere.
